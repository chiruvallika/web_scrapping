from flask import Flask, render_template, request, redirect, url_for, jsonify
import pyodbc

app = Flask(__name__)


server = 'DESKTOP-OPD33C4\\SQLEXPRESS01'
database = 'employee_details'
username = 'sa'
password = 'Oorwin@123'
conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+password)

@app.route('/')
def index():

    phone_numbers = []
    cursor = conn.cursor()
    try:
        cursor.execute('SELECT id, phone_number FROM phoneData')
        phone_numbers = cursor.fetchall()
    except pyodbc.Error as e:
        print("Error fetching data:", e)
    finally:
        cursor.close()
    return render_template('form.html', phone_numbers=phone_numbers)


@app.route('/send_data', methods=['POST'])
def send_data():
    phone_number = request.form.get('phoneNumber')
    edit_id = request.form.get('edit_id')

    cursor = conn.cursor()
    try:
        if edit_id:
            print("send data updated")
            cursor.execute('UPDATE phoneData SET phone_number = ? WHERE id = ?', (phone_number, edit_id))
        else:
            cursor.execute('INSERT INTO phoneData (phone_number) VALUES (?)', (phone_number,))
        conn.commit()
    except pyodbc.Error as e:
        print("Error executing query:", e)
    finally:
        cursor.close()

    return redirect(url_for('index'))


@app.route('/del_data/<int:id>', methods=['GET'])
def del_data(id):
    cursor = conn.cursor()
    try:
        cursor.execute('DELETE FROM phoneData WHERE id = ?', id)
        conn.commit()
    except pyodbc.Error as e:
        print("Error executing query:", e)
    finally:
        cursor.close()
    return redirect(url_for('index'))


@app.route('/edit_data/<int:id>', methods=['GET', 'POST'])
def edit_data(id):
    if request.method == 'GET':
        cursor = conn.cursor()
        try:
            cursor.execute('SELECT phone_number FROM phoneData WHERE id = ?', id)
            data = cursor.fetchone()
            return jsonify({'phone_number': data.phone_number})
        except pyodbc.Error as e:
            print("Error executing query:", e)
        finally:
            cursor.close()
        return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5001)
