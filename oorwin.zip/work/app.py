from flask import Flask,render_template,request,url_for,redirect, jsonify
import pyodbc

app  = Flask(__name__)


server = 'DESKTOP-OPD33C4\\SQLEXPRESS01'
database = 'companies_data'
username = 'sa'
password = 'Oorwin@123'

cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+password)

@app.route('/')
def form():
    cursor = cnxn.cursor()
    cursor.execute('select distinct acc_id,acc_name from accounts')
    accounts = cursor.fetchall()
    cursor.close()
    return render_template('form.html',accounts = accounts)

@app.route('/add_account',methods=['POST'])
def add_account():
    acc_name = request.form['acc_name']
    cursor = cnxn.cursor()
    cursor.execute('select count(*) from accounts where acc_name = ?',acc_name)
    count = cursor.fetchone()[0]
    if count>0:
        print("account already exist")
    if acc_name and count==0:
        cursor = cnxn.cursor()
        cursor.execute('insert into accounts(acc_name) values(?)',acc_name)
        cnxn.commit()
        cursor.close()
    return  redirect(url_for('form'))


@app.route('/employeeForm',methods=['post','get'])
def employeeForm():
    # acc_id = request.form.get('account_id')
    acc_id = request.form['account_id']
    print("account idd is")
    print(acc_id)
    cursor = cnxn.cursor()
    cursor.execute('select des_id,designation from designations')
    designations = cursor.fetchall()
    print(designations)
    cursor.close()
    designations_list = [{'des_id': row[0], 'designation': row[1]} for row in designations]
    return jsonify(designations=designations_list,acc_id=acc_id)

@app.route('/add_employee', methods=['POST'])
def add_employee():
    print("inside add employee")
    acc_id = request.form['accountID']
    print(acc_id)
    # acc_id = int(acc_id)
    des_id = request.form['designation_id']
    # des_id = int(des_id)
    emp_name = request.form['name']
    mobile_number = request.form['phone_number']
    try:
        if des_id and emp_name and mobile_number:
            cursor = cnxn.cursor()
            cursor.execute('INSERT INTO account_employee_details (acc_id, des_id, emp_name, mobile_number) VALUES (?, ?, ?, ?)', (acc_id, des_id, emp_name, mobile_number))
            cnxn.commit()
    except pyodbc.Error as e:
        print('Error:', e)
    finally:
        if 'cursor' in locals():
            cursor.close()

    return redirect(url_for('render_data'))

if __name__ == '__main__':
    app.run(debug=True,host='127.0.0.1',port=5001)