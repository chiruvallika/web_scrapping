from flask import Flask, request, render_template,url_for,redirect,jsonify
import pyodbc

server = 'DESKTOP-OPD33C4\\SQLEXPRESS01'
username = 'sa'
password = 'Oorwin@123'
database = 'employee_details'


cnxn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server='+server+';Database='+database+';UID='+username+';PWD='+password+';Trusted_connection=no')

app = Flask(__name__)

# create_table_query = '''
# create table phoneData(
# id int identity(1,1),
# phone_number int not null
# );
# '''
cursor = cnxn.cursor()
# cursor.execute(create_table_query)

@app.route('/')
def form():
    return render_template('form.html')

@app.route('/send_form_data', methods=['POST', 'GET'])
def send_form_data():
    if request.method == 'POST':
        phone_number = request.form.get('phoneNum')
        print(phone_number)

        if phone_number:
            try:
                cursor = cnxn.cursor()
                cursor.execute('INSERT INTO phoneData (phone_number) VALUES (?)', (phone_number,))
                cnxn.commit()
                cursor.close()
            except Exception as e:
                return f"An error occurred: {str(e)}"
        else:
            return "Phone number not received."

    cursor = cnxn.cursor()
    cursor.execute('SELECT * FROM phoneData')
    rows = cursor.fetchall()
    cursor.close()

    data = []
    for row in rows:
        data.append(dict(row))
    print(data)

    return jsonify({'success': True, 'data': data})


    

@app.route('/delete_data',methods=['POST'])
def delete_row():
    id = request.form.get('delete_row')
    cursor.execute('delete from phoneData where id = ?',id)
    cnxn.commit()
    return "row delted"
    

    
if __name__ == '__main__':
    app.run(debug=True,host = '127.0.0.1',port=5000)


    
