function validate(){
    var number = document.getElementById('phoneNumber').value;
    var isValid = true;
    if(number == null || number == ""){
        document.getElementById('phoneError').innerHTML = 'Phone number cannot be null.';
        isValid = false;
    }
    else if(number.length!=10){
        document.getElementById('phoneError').innerHTML = 'Max length is 10.';
        isValid = false;
    }
    else{
        document.getElementById('phoneError').innerHTML = "";
    }
    return isValid;
}