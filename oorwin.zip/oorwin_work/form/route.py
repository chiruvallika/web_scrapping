from flask import Flask,render_template, request, jsonify, redirect, url_for
import pyodbc

server= 'DESKTOP-OPD33C4\\SQLEXPRESS01'
username = 'sa'
password = 'Oorwin@123'
database = 'employee_details'
app = Flask(__name__)

cnxn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server='+server+';Database='+database+';UID='+username+';PWD='+password+';Trusted_connection=no')

# create_table = '''
# create table phoneTable(
# id int identity(1,1) primary key,
# phone_number int not null
# );
# '''

# with cnxn.cursor() as cursor:
#     cursor.execute(create_table)
#     cnxn.commit()

# @app.route('/')
# def form():
#     return render_template('form.html',data="")

@app.route('/send_data',methods=['POST','GET'])
def send_data():
    phone_number = request.form.get('phoneNumber')
    edit_id = request.form.get('edit_id')
    print("send data edit id")
    print(edit_id)
    print("helllo")
    if request.method == 'POST':
        print(phone_number)
        cursor = cnxn.cursor()
        if phone_number:
            if edit_id:
                print("editt clicked")
                cursor.execute('update phoneData set phone_number = ? where id = ?',phone_number,edit_id)
            else:
                try:
                    print("insert exec")
                    cursor.execute('INSERT INTO phoneData (phone_number) VALUES (?)', (phone_number,))
                    cnxn.commit()
                    cursor.close()
                except Exception as e:
                    return f"An error occurred: {str(e)}"
    cursor = cnxn.cursor()
    cursor.execute('SELECT * FROM phoneData')
    rows = cursor.fetchall()
    cursor.close()
    data = []
    for row in rows:
        row_dict = {
                'id': row.id,
                'username': row.phone_number,
            }
        data.append(row_dict)

    return render_template('form.html', data=data)

@app.route('/del_data',methods=['POST'])
def del_data():
    id = request.form.get('del_id')
    print(id)
    cursor = cnxn.cursor()
    cursor.execute('delete from phoneData where id =?',id)
    cnxn.commit()
    return redirect(url_for('send_data'))


@app.route('/edit_data',methods = ['POST'])
def editData():
    if request.method == 'POST':
        edit_id = request.form.get('edit_id')
        cursor = cnxn.cursor()
        cursor.execute('select * from phoneData where id = ?',edit_id)
        data = cursor.fetchone()
        print("edit data")
        print(data.phone_number)
        return jsonify({'phone_number': data.phone_number, 'redirect_url': url_for('send_data')})


if __name__ == '__main__':
    app.run(debug=True,host = '127.0.0.1',port=5001)