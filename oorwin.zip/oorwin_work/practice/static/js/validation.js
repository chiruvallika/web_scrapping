function validate(){
    var phone = document.getElementById('phone').value;
    var isValid = true;
    if(phone==null||phone==""){
        document.getElementById('phone_err').innerHTML = 'phone number cannot be null';
        isValid = false;
    }
    else if(phone.length != 10){
        document.getElementById('phone_err').innerHTML = 'MAX length is 10.';
        isValid = false;
    }
    else{
        document.getElementById('phone_err').innerHTML = "";
    }
    return isValid;
}