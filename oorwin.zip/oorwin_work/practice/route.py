from flask import Flask,render_template,request,url_for,redirect, jsonify
import pyodbc

app  = Flask(__name__)


server = 'DESKTOP-OPD33C4\\SQLEXPRESS01'
database = 'employee_details'
username = 'sa'
password = 'Oorwin@123'

cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+password)

@app.route('/')
def form():
    return render_template('form.html')

@app.route('/submit',methods=['POST'])
def submit():
    phone_number = request.form['phone']
    edit_id = request.form['editID']
    print(edit_id)
    try:       
        if phone_number:
            if edit_id:
                cursor = cnxn.cursor()
                cursor.execute('update phoneData set phone_number = ? where id = ?',(phone_number,edit_id))
                cnxn.commit()
            else:
                cursor = cnxn.cursor()
                cursor.execute('insert into phoneData(phone_number) values(?)',(phone_number))
                print("inserted data.")
                cnxn.commit()
    except pyodbc.Error as e:
        print('Error while fetching: ',e)
    finally:
        cursor.close()
    return redirect(url_for('form'))

@app.route('/get_data',methods = ['GET'])
def get_data():
    page = request.args.get('page',type=int)
    items_per_page = request.args.get('items_per_page',type=int)
    offset = (page - 1)*items_per_page
    try:
        cursor = cnxn.cursor()
        cursor.execute('select * from phoneData order by id offset ? rows fetch next ? rows only',(offset,items_per_page))
        rows = cursor.fetchall()
        data =[]
        for row in rows:
            dict={
                'id': row.id,
                'phone_number': row.phone_number,
            }
            data.append(dict)
    except pyodbc.Error as e:
        print('Error',e)
    finally:
        cursor.close()
    cursor = cnxn.cursor()
    cursor.execute('select count(*) from phoneData')
    count = cursor.fetchone()[0]
    return jsonify(data=data,total_records=count)

@app.route('/del_data',methods=['POST'])
def del_data():
    id = request.form.get('del_id')
    print(id)
    try:
        cursor = cnxn.cursor()
        cursor.execute('delete from phoneData where id = ?',id)
        print("Delted data")
        cnxn.commit()
    except pyodbc.Error as e:
        print('Error',e)
    finally:
        cursor.close()
    return redirect(url_for('form'))

@app.route('/edit/<int:id>',methods=['GET'])
def edit(id):
    try:
        cursor = cnxn.cursor()
        cursor.execute('select * from phoneData where id = ?',id)
        row = cursor.fetchone()
        data=[]
        dict = {
            'id':row.id,
            'phone_number':row.phone_number,
        }
        data.append(dict)
        return jsonify(data=data)
    except pyodbc.Error as e:
        print('Error',e)
    finally:
        cursor.close()
    return redirect(url_for('form'))





if __name__ == '__main__':
    app.run(debug=True,host='127.0.0.1',port=5002)
    
    