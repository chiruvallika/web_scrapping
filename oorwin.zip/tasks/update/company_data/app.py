from flask import Flask, render_template, request, jsonify
import pyodbc

app = Flask(__name__)

# Database connection parameters
server = 'DESKTOP-OPD33C4\\SQLEXPRESS01'
database = 'companies_data'
username = 'sa'
password = 'Oorwin@123'

# Establishing connection to the SQL Server database
cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+password)

@app.route('/')
def index():
    # Fetch existing account names and IDs from the database
    cursor = cnxn.cursor()
    cursor.execute("SELECT acc_id, acc_name FROM accounts")
    accounts = [{'id': row.acc_id, 'name': row.acc_name} for row in cursor.fetchall()]
    cursor.execute("SELECT des_id, designation FROM designations")
    designations = [{'id': row.des_id, 'name': row.designation} for row in cursor.fetchall()]
    cursor.close()
    return render_template('form.html', accounts=accounts, designations=designations)

@app.route('/submit_data', methods=['POST'])
def submit_data():
    if request.method == 'POST':
        form_type = request.form['form_type']
        if form_type == 'account':
            acc_name = request.form['acc_name']
            # Insert account name into the database
            cursor = cnxn.cursor()
            cursor.execute("INSERT INTO accounts (acc_name) VALUES (?)", acc_name)
            cnxn.commit()
            cursor.close()
            # Fetch updated list of accounts and return in the response
            cursor = cnxn.cursor()
            cursor.execute("SELECT acc_id, acc_name FROM accounts")
            accounts = [{'id': row.acc_id, 'name': row.acc_name} for row in cursor.fetchall()]
            cursor.close()
            return jsonify({'message': 'Account added successfully!', 'accounts': accounts})
        elif form_type == 'designation':
            designation = request.form['designation']
            # Insert designation into the database
            cursor = cnxn.cursor()
            cursor.execute("INSERT INTO designations (designation) VALUES (?)", designation)
            cnxn.commit()
            cursor.close()
            # Fetch updated list of designations and return in the response
            cursor = cnxn.cursor()
            cursor.execute("SELECT des_id, designation FROM designations")
            designations = [{'id': row.des_id, 'name': row.designation} for row in cursor.fetchall()]
            cursor.close()
            return jsonify({'message': 'Designation added successfully!', 'designations': designations})
        elif form_type == 'employee':
            acc_id = request.form['account']
            des_id = request.form['designation']
            emp_name = request.form['emp_name']
            mobile_number = request.form['mobile_number']
            # Insert employee data into the database
            cursor = cnxn.cursor()
            cursor.execute("INSERT INTO account_employee_details (acc_id, des_id, emp_name, mobile_number) VALUES (?, ?, ?, ?)", acc_id, des_id, emp_name, mobile_number)
            cnxn.commit()
            cursor.close()
            return jsonify({'message': 'Employee data submitted successfully!'})
        
@app.route('/render_data', methods=['GET'])
def render_data_page():
    return render_template('showData.html')
        
@app.route('/employee_data')
def get_employee_data():
    cursor = cnxn.cursor()
    cursor.execute("""
        SELECT acc.acc_name, emp.emp_name, emp.mobile, des.designation 
        FROM account_employee_details emp 
        JOIN accounts acc ON acc.acc_id = emp.acc_id 
        JOIN designations des ON des.des_id = emp.des_id
    """)
    rows = cursor.fetchall()
    cursor.close()

    employee_data = []
    for row in rows:
        employee_data.append({
            'account_name': row.acc_name,
            'employee_name': row.emp_name,
            'mobile_number': row.mobile,
            'designation': row.designation
        })

    return jsonify({'employees': employee_data})

if __name__ == '__main__':
    app.run(debug=True,host='127.0.0.1',port=5001)
